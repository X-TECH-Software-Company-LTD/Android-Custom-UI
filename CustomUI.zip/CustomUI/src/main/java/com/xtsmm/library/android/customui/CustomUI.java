package com.xtsmm.library.android.customui;

import android.app.Activity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.card.MaterialCardView;

public class CustomUI {

    Activity activity;
    View layout;
    public CustomUI(Activity activity) {
        this.activity = activity;
    }


}
